#!/usr/bin/python
#simple python csv parser that export Comma
#Separated Value data into a MySQL database.
#phillip@bailey.st
import csv
import MySQLdb
# open the connection to the MySQL server.
# using MySQLdb
mydb = MySQLdb.connect(host='localhost',
    user='csv',
    passwd='csv',
    db='csvdb')
cursor = mydb.cursor()
# read the presidents.csv file using the python
# csv module http://docs.python.org/library/csv.html
csv_data = csv.reader(file('presidents.csv'))
# execute the for clicle and insert the csv into the
# database.
for row in csv_data:

    cursor.execute('INSERT INTO PRESIDENTS(PRESIDENCY ,PRESIDENT \
            ,TOOKOFFICE ,LEFTOFFICE ,PARTY ,HOMESTATE)' \
            'VALUES(%s, %s, %s, %s, %s, %s)',  row)
#close the connection to the database.
cursor.close()
print "Import to MySQL is over"
