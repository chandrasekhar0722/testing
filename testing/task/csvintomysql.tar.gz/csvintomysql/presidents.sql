CREATE DATABASE csvdb; 
USE csvdb;
GRANT ALL ON  csvdb.* TO csv@localhost IDENTIFIED BY 'csv';

CREATE TABLE `PRESIDENTS` (
                id INT NOT NULL AUTO_INCREMENT,
                PRIMARY KEY(id) ,
                cur_timestamp TIMESTAMP ,
                `PRESIDENCY` char(2) DEFAULT NULL,
                `PRESIDENT` char(50) DEFAULT NULL,
                `TOOKOFFICE` char(10) DEFAULT NULL,
                `LEFTOFFICE` char(11) DEFAULT NULL,
                `PARTY` char(60) DEFAULT NULL,
                `HOMESTATE` char(60) DEFAULT NULL)

